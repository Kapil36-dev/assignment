import { useState } from 'react';
import './App.css';
import Home from './home';

function App() {
  const [data, setdata] = useState([{ key: "", value:false }])
  const [option,setoption] = useState();
  const [result,setresult] = useState();
  const handleclick = () => {
    setdata([...data, { key: "", value: false }])
  }
  const handleresults=()=>{
    setresult([...result,[]])
  }

  const handlechange = (e, i) => {
    const onchangeval = [...data]
    onchangeval[i].key = e.target.value
    setdata(onchangeval)
  }

  const handleselect = (e, i) => {
    const onselectval = [...data]
    onselectval[i].value = e.target.value
    setdata(onselectval)
  }


  const handleoption = (e)=>{
    if(e.target.value==="1"){
      setresult('false');
      console.log(result);
    }
    setoption(e.target.value)
  }

  const handleresult=(e)=>{
    setresult(e.target.value)
  }

  const deletemyargs =()=>{
    setoption()
    setresult('undefine')
  }

  return (
    <div>
      {/* {
        data.map((val, i) => {
          return (
            <div>
              <input name='key' onChange={(e) => { handlechange(e, i) }} />
              <select name="value" id="" onClick={(e) => { handleselect(e, i) }}>
                <option value={false}>false</option>
                <option value={true}>True</option>
              </select>
            </div>
          )
        })
      }
      <button onClick={handleclick}>add</button>


      <div >
        {
          option==='1'?
          <div>
          <select name="" id="" onClick={(e)=>handleresult(e)}>
            <option value={true}>True</option>
            <option value={false} selected>false</option>
          </select>
          <button onClick={deletemyargs}>delete</button>
          </div>
          :
          option==='2'?
          <div>
            <select name="" id="" onClick={(e)=>handleresult(e)}>
            <option value="" selected disabled>select.....</option>
              {data.filter((val)=>{return val.value!==""}).map((val,i)=>{
                return(
                    <option value={val.value}>{val.key}</option>
                )
              })}
            </select>
            <button onClick={deletemyargs}>delete</button>
          </div>
          :<select name="" id="" onClick={(e)=>handleoption(e)}>
          <option value="" selected disabled>select.....</option>
          <option value="1">constant</option>
          <option value="2">my arug</option>
          <option value="3">and</option>
          <option value="4">or</option>
        </select>
        }
        {
          result?
          <div>result: {result}</div>:
          <div>result: undefine</div>
        }
      </div> */}
      <Home/>
    </div>
  );
}

export default App;
